<?php $__env->startSection('content'); ?>
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>
	
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<section class="container mt-5 pt-5">	
		<ol class="breadcrumb">
			<li class="breadcrumb-item active"><a href="<?php echo e(route('administrador')); ?>">Perfil</a></li>
			<li class="breadcrumb-item active"> Usuarios Registrados </li>
			<li class="breadcrumb-item active"><a href="<?php echo e(route('administradorTabla')); ?>"> Ver Solicitudes </a></li>
			<li class="breadcrumb-item active"><a href="<?php echo e(route('reportes')); ?>">Ver Registros del Sistema</a></li>
		</ol>
		<div class="container">
			<h3 class="text-uppercase text-center"><b>USUARIOS</b></h3>
				<div class="tablaSolicitudes">
					<form id="formEstado" name="formEstado" method="post" action="<?php echo e(route('estadoSolicitud', '$solicitud->id')); ?>">
					<?php echo e(csrf_field()); ?>

						<table id="tablaUsuarios" class="table table-bordered" style="align:center">
							<thead>
								<tr>
									<th>Nombre</th>
									<th>E-Mail</th>
									<th>Rol</th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($usuario['name']); ?></td>
									<td><?php echo e($usuario['email']); ?></td>
									<?php if($usuario->type == 'solicitante'): ?>
										<td bgcolor="orange"><b><?php echo e($usuario['type']); ?></b></td>
									<?php endif; ?>
									<?php if($usuario->type == 'autorizador'): ?>
										<td bgcolor="blue"><b><?php echo e($usuario['type']); ?></b></td>
									<?php endif; ?>
									<?php if($usuario->type == 'admin'): ?>
										<td bgcolor="#006600"><b><?php echo e($usuario['type']); ?></b></td>
									<?php endif; ?>
									<?php if($usuario->type == 'default'): ?>
										<td><a href="<?php echo e(route('modificarUsuario', $usuario->id)); ?>" class="btn btn-primary">Editar</a></td>
									<?php endif; ?>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
						<a class="btn btn-primary" href="<?php echo e(route('administrador')); ?>" role="button"> Volver al Perfil </a>
					</form>
				</div>
			</div>
	</section>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaUsuarios').dataTable();
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>