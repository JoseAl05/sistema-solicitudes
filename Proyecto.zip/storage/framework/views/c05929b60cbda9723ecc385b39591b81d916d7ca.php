<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<div class="formatoBuscar">
		<h1><b>Buscar Solicitudes</h1></b>
		<form id="formSolicitud"  method="post" action="<?php echo e(route('ver_solicitud')); ?>">
			<?php echo e(csrf_field()); ?>

			<label for="solicitud" style="display:inline-block">Ingrese número de solicitud que desea revisar</label>
			<div class="buscarSolicitud">
				<input type="text" class="form-control" id="solicitud" name="solicitud" required>
			</div>
			<br>
			<div class="botonBuscar">
				<button type="submit" class="btn btn-primary">Ver Solicitud</button>
			</div>
		</form>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>