<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
  <h4 class="tituloSolicitud">SOLICITUD DE REQUERIMIENTO DEL BIEN O SERVICIO</h4>
	<div class="col col-lg-3">
        <div class="card-body">
            <div class="container mt-4">
				<div class="formulario">
				  <form id="form-alumno-nuevo" action="<?php echo e(route('SolicitudDeVentas.store')); ?>" method="post">
					<div class="form-group">
						<div class="labelNumeroSolicitud">
							<label for="numeroSolicitud">Numero de Solicitud: </label>
						</div>
						<div class="numeroSolicitud">
							<input type="text" class="form-control" id="numeroSolicitud" name="numeroSolicitud">
						</div>
						<div class="labelFecha">
							<label for="fecha">Fecha: </label>
						</div>
						<div class="fecha">
							<input type="text" class="form-control" id="fecha" placeHolder="dd/mm/yyyy" name="fecha">
						</div>
						<div class="labelUnidad">
							<label for="unidad">Unidad Solicitante: </label>
						</div>
						<div class="unidad">
							<input type="text" class="form-control" id="unidad" placeHolder="Ingrese unidad solicitante....." name="unidad">
						</div>
						<div class="labelBien">
							<label for="unidad">Nombre Bien/Servicio: </label>
						</div>
						<div class="nombreBien">
							<input type="text" class="form-control" id="unidad" placeHolder="Ingrese nombre del bien o servicio....." name="nombreBien">
						</div>
						<div class="tabla">
							<div class="labelDescripcion">
								<label for="descripcion">Descripcion Bien/Servicio: </label>
							</div>
							<table class="table table-striped">
								<thead>
									<tr>
									  <th scope="col">Detalle del Bien/Servicio</th>
									  <th scope="col">Unidad de Medida</th>
									  <th scope="col">Cantidad Requerida</th>
									</tr>
											<td scope="row">
												<div class="columna1">
													<input id="detalle" name="detalle" type="textField" class="form-control input-md">
												</div>
											</td>
											<td>
												<div class="columna2">
													<input id="unidadMedida" name="unidadMedida" type="text" class="form-control input-md">
												</div>
											</td>
											<td>
												<div class="columna3">
													<input id="cantidad" name="cantidad" type="text" class="form-control input-md">
												</div>
											</td>
											

									</tr>
								</thead>
							</table>
						</div>
						<div class="labelJustificacion">
							<label for="justificacion">Justificacion Bien/Servicio: </label>
						</div>
						<div class="justificacion">
							<input type="text" class="form-control" id="justificacion" name="justificacion">
						</div>
						<div class="labelObservaciones">
							<label for="observaciones">Observaciones: </label>
						</div>
						<div class="observaciones">
							<input type="text" class="form-control" id="observaciones" name="observaciones">
						</div>
						<div class="labelFechaAprox">
							<label for="observaciones">Fecha aprox. para cuando se requiere: </label>
						</div>
						<div class="fechaAprox">
							<input type="text" class="form-control" id="observaciones" placeholder="dd/mm/yyyy" name="fechaAprox">
						</div>
					</div>
					<button type="submit" class="btn btn-primary">Enviar Solicitud</button>
				   </form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>