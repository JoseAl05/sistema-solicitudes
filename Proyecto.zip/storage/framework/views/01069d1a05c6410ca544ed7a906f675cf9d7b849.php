<?php $__env->startSection('content'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
	<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<section class="container mt-5 pt-5">
		<h3 class="text-uppercase text-center">MODIFICAR DATOS DE <?php echo e($nombre); ?></h3>
		<div class="container">
		<div class="alert alert-success" style="display:none"></div>
			<form method="post" action="<?php echo e(route('editarUsuario',$usuario->id)); ?>">
			<?php echo e(csrf_field()); ?>

			<?php echo e(method_field('PATCH')); ?>

					<div class="form-group row">
						<label for="asunto" class="col-sm-2 form-control-label">Rol: </label>
						<div class="selectTipo">
							<select name="type" class="custom-select" id="type">
								<option value="solicitante" class="form-control">Solicitante</option>
								<option value="autorizador" class="form-control" selected>Autorizador</option>
							</select>
						</div>
					</div>
				<button class="btn btn-primary" type="submit" id="botonAgregar">Modificar Usuario</button>
				<a class="btn btn-primary" href="<?php echo e(route('mostrarUsuarios')); ?>" role="button"> Volver </a>
				<a class="btn btn-primary" href="<?php echo e(route('administrador')); ?>" role="button"> Volver al Perfil </a>
			</form>
		</div>
	</section>
	<script>
		jQuery(document).ready(function(){
			jQuery('#botonAgregar').click(function(e){
				e.preventDefault();
				$.ajaxSetup({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
					}
				});
				jQuery.ajax({
					url: "<?php echo e(url('/AgregarUsuario')); ?>",
					method: 'post',
					data: {
						type: jQuery('#type').val()
					},
					success: function(result){
						console.log(result);
						swal({
							title: "Éxito!",
							text: "Usuario Modificado Correctamente!",
							icon: "success",
						});
					}
				});
			});
		});
	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>