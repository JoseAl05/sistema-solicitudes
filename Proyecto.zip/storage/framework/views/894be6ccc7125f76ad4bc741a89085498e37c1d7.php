<?php $__env->startSection('content'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
	<link rel="stylesheet" href="sweetalert2.min.css">
	<script type="text/javascript" src="/js/java.js?v=2.1"></script>
	<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<script src="sweetalert2.all.min.js"></script>
	<!-- Optional: include a polyfill for ES6 Promises for IE11 and Android browser -->
	<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
	  <h4 class="tituloSolicitud">SOLICITUD DE REQUERIMIENTO DEL BIEN O SERVICIO</h4>
		<div class="col col-lg-3">
			<div class="card-body">
				<div class="container mt-4">
					<div class="formulario">
					  <form id="formSolicitud"  method="post" action="<?php echo e(route('enviar_solicitud')); ?>">
						<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<div class="labelNumeroSolicitud">
								<label for="numeroSolicitud">Numero de Solicitud: </label>
							</div>
							<div class="numeroSolicitud">
								<input type="text" class="form-control" id="numeroSolicitud" name="numeroSolicitud" required>
							</div>
							<div class="labelFecha">
								<label for="fecha">Fecha: </label>
							</div>
							<div class="fecha">
								<input type="text" class="form-control" id="fecha" placeHolder="dd/mm/yyyy" name="fecha" required>
							</div>
							<div class="labelUnidad">
								<label for="unidad">Unidad Solicitante: </label>
							</div>
							<div class="unidad">
								<input type="text" class="form-control" id="unidad" placeHolder="Ingrese unidad solicitante....." name="unidad" required>
							</div>
							<div class="labelBien">
								<label for="unidad">Nombre Bien/Servicio: </label>
							</div>
							<div class="nombreBien">
								<input type="text" class="form-control" id="unidad" placeHolder="Ingrese nombre del bien o servicio....." name="nombreBien" required>
							</div>
							<div class="tabla">
								<div class="labelDescripcion">
									<label for="descripcion">Descripcion Bien/Servicio: </label>
								</div>
								<table class="table table-striped">
									<thead>
										<tr>
										  <th scope="col">Detalle del Bien/Servicio</th>
										  <th scope="col">Unidad de Medida</th>
										  <th scope="col">Cantidad Requerida</th>
										</tr>
												<td scope="row">
													<div class="columna1">
														<input id="detalle" name="detalle" type="textField" class="form-control input-md" required>
													</div>
												</td>
												<td>
													<div class="columna2">
														<input id="unidadMedida" name="unidadMedida" type="text" class="form-control input-md" required>
													</div>
												</td>
												<td>
													<div class="columna3">
														<input id="cantidad" name="cantidad" type="text" class="form-control input-md" required>
													</div>
												</td>
									</thead>
								</table>
							</div>
							<div class="labelJustificacion">
								<label for="justificacion">Justificacion Bien/Servicio: </label>
							</div>
							<div class="justificacion">
								<input type="text" class="form-control" id="justificacion" name="justificacion" required>
							</div>
							<div class="labelObservaciones">
								<label for="observaciones">Observaciones: </label>
							</div>
							<div class="observaciones">
								<input type="text" class="form-control" id="observaciones" name="observaciones">
							</div>
							<div class="labelFechaAprox">
								<label for="observaciones">Fecha aprox. para cuando se requiere: </label>
							</div>
							<div class="fechaAprox">
								<input type="text" class="form-control" id="observaciones" placeholder="dd/mm/yyyy" name="fechaAprox" required>
							</div>
						</div>
						<button type="submit" class="btn btn-primary" id="botonEnviar" name="ruta">Enviar Solicitud</button>
					</form>
					</div>
				</div>
			</div>
		</div>
		<script type="text/javascript">
			window.onload = function(){
				$.ajaxSetup({
					headers:{
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					}
				});
			}
			function guardarSolicitud()
			{
				$.ajax({
					headers: {
						'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type:"POST",
					data: $('#formSolicitud').serialize(),
					url: "<?php echo e(url('/enviar_solicitud')); ?>",
					success: function(data){
						if(data != 1)
						{
							swal.fire({
								title: "Éxito!",
								text: mensaje,
								type: "success"
							}).then(function () {
								window.location.reload();
							}
						}
					}
				});
			}
		</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>