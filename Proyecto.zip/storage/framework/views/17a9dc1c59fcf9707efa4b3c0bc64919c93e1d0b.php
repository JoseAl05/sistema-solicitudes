	<section class="container mt-5 pt-5">	
		<ol class="breadcrumb">
			<li class="breadcrumb-item active"><a href="<?php echo e(route('solicitante')); ?>">Perfil</a></li>
			<li class="breadcrumb-item active"><a href="<?php echo e(route('Solicitud')); ?>"> Agregar Solicitud </a></li>
			<li class="breadcrumb-item active"><a href="<?php echo e(route('VerTabla')); ?>"> Ver Estados de Solicitud </a></li>
		</ol>
		<div class="container mt-4">
			<h4 class="tituloSolicitud">SOLICITUD DE COMPRA N° <?php echo e($solicitud['id']); ?></h4>
			<div class="formulario" style="width:70%; margin:50px;">
				<div class="mostrarFecha">
					<p align="right"><b>Fecha Envio:</b> <?php echo e($solicitud->created_at->format('Y-m-d')); ?></p>
				</div>
				<div class="mostrarUnidad">
					<p><b>Unidad Solicitante:</b><?php echo e($solicitud['UnidadSolicitante']); ?></p>
				</div>
				<div class="mostrarNombreBienServicio">
					<p><b>Nombre Bien/Servicio:</b> <?php echo e($solicitud['NombreBienServicio']); ?></p>
				</div>
				<div class="mostrarDescripcionBienServicio">
					<p><b>Descripcion Bien/Servicio: </b></p>
				</div>
				<div class="tabla">
					<div class="container">
						<div class="tablaMostrar">
							<table class="table table-bordered">
								<thead>
									<tr>
										<th>Detalle del Bien/Servicio</th>
										<th>Unidad de Medida</th>
										<th>Cantidad Requerida</th>
										<th>Enlace Adjunto</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td><?php echo e($solicitud['DetalleBienServicio']); ?></td>
										<td><?php echo e($solicitud['UnidadDeMedida']); ?></td>
										<td><?php echo e($solicitud['CantidadRequerida']); ?></td>
										<td><a href="<?php echo e($solicitud['Enlace']); ?>" target="_blank">Ir al Enlace</a></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="mostrarJustificacion">
					<p><b>Justificacion:</b> <div class="casillaJustificacion"><p style="padding-left:5px"><?php echo e($solicitud['JustificacionBienServicio']); ?></p></p><br></div>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Observaciones:</b><div class="casillaObservaciones"><p style="padding-left:5px"><?php echo e($solicitud['Observaciones']); ?></p></p><br></div>
				</div>
				<div class="mostrarFechaAprox">
					<p><b>Fecha aprox. para cuando se requiere:</b> <?php echo e($solicitud['fechaAproximada']); ?></p>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Estado Solicitud:</b><?php echo e($solicitud['estadoSolicitud']); ?></p></div>
				</div>
				<?php if($solicitud->estadoSolicitud == 'Rechazada'): ?>
					<div class="mostrarObs">
						<p><b>Observacion sobre Rechazo:</b><?php echo e($solicitud['ObservacionEstado']); ?></p>
					</div>
				<?php endif; ?>
	</section>