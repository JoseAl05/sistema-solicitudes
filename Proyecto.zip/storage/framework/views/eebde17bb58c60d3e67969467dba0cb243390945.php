<?php $__env->startSection('content'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
	<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
	<script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>
	<section class="container mt-5 pt-5">		
		<div class="container mt-4">
			<ol class="breadcrumb">
				<li class="breadcrumb-item active"><a href="<?php echo e(route('administrador')); ?>">Perfil</a></li>
				<li class="breadcrumb-item active"><a href="<?php echo e(route('mostrarUsuarios', Auth::user())); ?>"> Usuarios Registrados </a></li>
				<li class="breadcrumb-item active"><a href="<?php echo e(route('administradorTabla')); ?>"> Ver Solicitudes </a></li>
				<li class="breadcrumb-item active"><a href="<?php echo e(route('reportes')); ?>">Ver Registros del Sistema</a></li>
			</ol>
			<h4 class="tituloSolicitud">SOLICITUD DE COMPRA N° <?php echo e($mostrarSolicitud['id']); ?></h4>
			<div class="formulario" style="width:70%; margin:50px;">
				<div class="mostrarFecha">
					<p align="right"><b>Fecha Envio:</b> <?php echo e($mostrarSolicitud->created_at->format('Y-m-d')); ?></p>
				</div>
				<div class="mostrarUnidad">
					<p><b>Unidad Solicitante:</b><?php echo e($mostrarSolicitud['UnidadSolicitante']); ?></p>
				</div>
				<div class="mostrarNombreBienServicio">
					<p><b>Nombre Bien/Servicio:</b> <?php echo e($mostrarSolicitud['NombreBienServicio']); ?></p>
				</div>
				<div class="mostrarDescripcionBienServicio">
					<p><b>Descripcion Bien/Servicio: </b></p>
				</div>
				<div class="tabla">
					<div class="container">
						<div class="tablaMostrar">
							<table class="table table-bordered">
								<thead>
									<tr>
										<th>Detalle del Bien/Servicio</th>
										<th>Unidad de Medida</th>
										<th>Cantidad Requerida</th>
										<th>Enlace Adjunto</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->DetalleBienServicio); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($detalle); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->UnidadDeMedida); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($unidad); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->CantidadRequerida); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cantidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($cantidad); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->Enlace); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mostrarSolicitud->Enlace != 'https://www.google.cl/'): ?>
													No se adjunto ningun enlace
													<hr>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->Enlace); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mostrarSolicitud->Enlace == 'https://www.google.cl/'): ?>
													<a href="<?php echo e($enlace); ?>" target="_blank">Ir al Enlace</a>
													<hr> 
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div>
				<div class="mostrarJustificacion">
					<p><b>Justificacion:</b> <div class="casillaJustificacion"><p style="padding-left:5px"><?php echo e($mostrarSolicitud['JustificacionBienServicio']); ?></p></p></div>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Observaciones:</b><div class="casillaObservaciones"><p style="padding-left:5px"><?php echo e($mostrarSolicitud['Observaciones']); ?></p></p></div>
				</div>
				<div class="mostrarFechaAprox">
					<p><b>Fecha aprox. para cuando se requiere:</b> <?php echo e($mostrarSolicitud['fechaAproximada']); ?></p>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Estado Solicitud:</b><?php echo e($mostrarSolicitud['estadoSolicitud']); ?></p></div>
				</div>
				<?php if($mostrarSolicitud->estadoSolicitud == 'Rechazada'): ?>
					<div class="mostrarObs">
						<p><b>Observacion sobre Rechazo:</b><?php echo e($mostrarSolicitud['ObservacionEstado']); ?></p>
					</div>
				<?php endif; ?>
		</div>
	</section>
	<script type="text/javascript">
		window.onload = function(){
			$.ajaxSetup({
				headers : {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				}
			});
		}
		function editarEstado($id)
		{
			swal({
				title: 'Espera un momento!',
				text: 'Trabajando tu solicitud..',
				allowOutsideClick: false,
				allowEscapeKey: false,
				allowEnterKey: false,
				onOpen: () => {
					swal.showLoading()
				}
			})
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				},
				type: "POST",
				data: $('#formEstado').serialize(),
				url: "<?php echo e(url('/EjecutarSolicitud/$id')); ?>",
				success: function(response){
					if(response =! 1)
					{
						console.log(response);
					}
					else
					{
						window.location.href = "<?php echo e(url('/PerfilAutorizador')); ?>";
					}
				}
			});
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>