<?php $__env->startSection('content'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<section class="container mt-5 pt-5">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="<?php echo e(route('autorizador')); ?>">Perfil</a></li>
					<li class="breadcrumb-item active"><a href="<?php echo e(route('autorizadorTabla')); ?>"> Ver Solicitudes </a></li>
				</ol>
			</div>
		</div>
		<div class="container mt-4">
			<h4 class="tituloSolicitud">SOLICITUD DE COMPRA N° <?php echo e($mostrarSolicitud['id']); ?></h4>
			<div class="formulario" style="width:70%; margin:50px;">
				<div class="mostrarFecha">
					<p align="right"><b>Fecha Envio:</b> <?php echo e($mostrarSolicitud->created_at->format('Y-m-d')); ?></p>
				</div>
				<div class="mostrarUnidad">
					<p><b>Unidad Solicitante:</b><?php echo e($mostrarSolicitud['UnidadSolicitante']); ?></p>
				</div>
				<div class="mostrarNombreBienServicio">
					<p><b>Nombre Bien/Servicio:</b> <?php echo e($mostrarSolicitud['NombreBienServicio']); ?></p>
				</div>
				<div class="mostrarDescripcionBienServicio">
					<p><b>Descripcion Bien/Servicio: </b></p>
				</div>
				<div class="container">
					<div class="tablaMostrar">
						<table class="table table-bordered">
								<thead>
									<tr>
										<th>Detalle del Bien/Servicio</th>
										<th>Unidad de Medida</th>
										<th>Cantidad Requerida</th>
										<th>Enlace Adjunto</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->DetalleBienServicio); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($detalle); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->UnidadDeMedida); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($unidad); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->CantidadRequerida); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cantidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php echo e($cantidad); ?>

												<hr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
										<td>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->Enlace); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mostrarSolicitud->Enlace != 'https://www.google.cl/'): ?>
													No se adjunto ningun enlace
													<hr>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<?php $__currentLoopData = json_decode($mostrarSolicitud->Enlace); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enlace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mostrarSolicitud->Enlace == 'https://www.google.cl/'): ?>
													<a href="<?php echo e($enlace); ?>" target="_blank">Ir al Enlace</a>
													<hr> 
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</td>
									</tr>
								</tbody>
							</table>
					</div>
				</div>
				<div class="mostrarJustificacion">
					<p><b>Justificacion:</b> <div class="casillaJustificacion"><p style="padding-left:5px"><?php echo e($mostrarSolicitud['JustificacionBienServicio']); ?></p></p></div>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Observaciones:</b><div class="casillaObservaciones"><p style="padding-left:5px"><?php echo e($mostrarSolicitud['Observaciones']); ?></p></p></div>
				</div>
				<div class="mostrarFechaAprox">
					<p><b>Fecha aprox. para cuando se requiere:</b> <?php echo e($mostrarSolicitud['fechaAproximada']); ?></p>
				</div>
				<div class="mostrarObservaciones">
					<p><b>Estado Solicitud:</b><?php echo e($mostrarSolicitud['estadoSolicitud']); ?></p>
					<p><b>Obs:</b><?php echo e($mostrarSolicitud['ObservacionEstado']); ?></p>
				</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>