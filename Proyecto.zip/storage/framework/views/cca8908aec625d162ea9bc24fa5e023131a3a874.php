<?php $__env->startSection('content'); ?>
<head>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.2/js/bootstrap-select.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
	<section class="container mt-5 pt-5">
		<ol class="breadcrumb">
			<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('autorizador')); ?>">Perfil</a></li>
			<li class="breadcrumb-item active"> Ver Solicitudes </li>
		</ol>
		<h1 class="page-header" align="center">SOLICITUDES</h1>
		<div class="container">
				<div class="tablaSolicitudes">
				<?php $__currentLoopData = $autorizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autorizador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<form id="formEstado" name="formEstado" method="post" action="<?php echo e(route('estadoSolicitud',$autorizador->id)); ?>">
					<?php echo e(csrf_field()); ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<table class="table table-bordered" style="align:center" id="tablaSolicitudes">
							<thead>
								<tr>
									<th>Numero de Solicitud</th>
									<th>Unidad Solicitante</th>
									<th>Usuario</th>
									<th>Fecha</th>
									<th>Estado Solicitud</th>
									<th>Ver Solicitud</th>
									<th>Editar Solicitud</th>
								</tr>
							</thead>
							<tbody>
							<?php $__currentLoopData = $autorizadores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autorizador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($autorizador['id']); ?></td>
									<td><?php echo e($autorizador['UnidadSolicitante']); ?></td>
									<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($autorizador->user_id == $usuario->id): ?>
											<td><?php echo e($usuario->name); ?></td>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<td><?php echo e($autorizador->created_at->format('d.m.Y')); ?></td>
									<td><?php echo e($autorizador->estadoSolicitud); ?></td>
									<td><a href="<?php echo e(route('VerSolicitud', $autorizador->id)); ?>" class="btn btn-primary">Ver Solicitud</a></td>
									<?php if($autorizador->estadoSolicitud =='Aprobada'): ?>
										<td><a href="<?php echo e(route('editarEstado', $autorizador->id)); ?>" class="btn btn-warning">Editar Estado</a></td>
									<?php endif; ?>
									<?php if($autorizador->estadoSolicitud =='Rechazada'): ?>
										<td><a href="<?php echo e(route('editarEstado', $autorizador->id)); ?>" class="btn btn-warning">Editar Estado</a></td>
									<?php endif; ?>
									<?php if($autorizador->estadoSolicitud =='Pendiente'): ?>
										<td><a href="<?php echo e(route('editarEstado', $autorizador->id)); ?>" class="btn btn-warning">Editar Estado</a></td>
									<?php endif; ?>
									<?php if($autorizador->estadoSolicitud == 'Compra Realizada' || $autorizador->estadoSolicitud == 'Anulada' || $autorizador->estadoSolicitud == 'Compra En Ejecucion'): ?>
										<td>No se puede editar</td>
									<?php endif; ?>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</form>
				</div>
		</div>
	</section>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaSolicitudes').dataTable();
		});
	</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>