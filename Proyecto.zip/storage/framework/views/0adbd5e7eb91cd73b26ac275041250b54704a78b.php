<?php $__env->startSection('content'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
	<script type="text/javascript" src="../js/jquery.js"></script>
	<script type="text/javascript" src="../js/jquery-ui-1.9.2.custom.min"></script>
	<script src="//cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
	<link type="text/css" href="../css/redmond/jquery-ui-1.8.20.custom.css" rel="Stylesheet"/>
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
	
	<section class="container mt-5 pt-5">	
		<ol class="breadcrumb">
			<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('solicitante')); ?>">Perfil</a></li>
			<li class="breadcrumb-item active"><a href="<?php echo e(route('Solicitud')); ?>"> Agregar Solicitud </a></li>
			<li class="breadcrumb-item active">Ver Estados de Solicitud</li>
		</ol>
		<h1 class="page-header" align="center">ESTADOS DE SOLICITUDES</h1>
		<div class="container">
				<div class="tablaSolicitudes">
					<table id="tablaEstados" style="align:center" class="table table-bordered table-hover table-condensed">
						<thead>
							<tr>
								<th>Numero de Solicitud</th>
								<th>Fecha</th>
								<th>Estado de Solicitud</th>
							</tr>
						</thead>
						<tbody>
						<?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $solicitud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($solicitud->user_id == Auth::user()->id): ?>
							<tr>
								<td scope="col"><?php echo e($solicitud['id']); ?></td>
								<td scope="col"><?php echo e($solicitud['fechaEnvio']); ?></td>
								<?php if($solicitud->estadoSolicitud == 'Aprobada'): ?>
									<td bgcolor="green" scope="col"><?php echo e($solicitud['estadoSolicitud']); ?></td>
								<?php endif; ?>
								<?php if($solicitud->estadoSolicitud == 'Rechazada'): ?>
									<td bgcolor="red" scope="col"><?php echo e($solicitud['estadoSolicitud']); ?></td>
								<?php endif; ?>
								<?php if($solicitud->estadoSolicitud == 'Pendiente'): ?>
									<td bgcolor="gray" scope="col"><?php echo e($solicitud['estadoSolicitud']); ?></td>
								<?php endif; ?>
								<td scope="col"><a class="btn btn-primary" href="<?php echo e(route('SolicitudSolicitante',$solicitud)); ?>">Ver Solicitud</a></td>
							</tr>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
			</div>
	</section>
	<script type="text/javascript">
		$(document).ready(function(){
			$('#tablaEstados').dataTable();
		});
	</script>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>