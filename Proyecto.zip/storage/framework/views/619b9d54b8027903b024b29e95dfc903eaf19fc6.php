<?php $__env->startSection('content'); ?>
<head>
	<meta name="_token" content="<?php echo e(csrf_token()); ?>" />
	<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
	<link rel="stylesheet" type="text/css" href="css/jquery-ui-1.7.2.custom.css" />
	<link rel="stylesheet" href= "https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<script src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
	<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.2/jquery-ui.min.js"></script>
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<script src="https://cdn.jsdelivr.net/npm/promise-polyfill"></script>
	<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
</head>
	<section class="container mt-5 pt-5">
		<div class="row">
			<div class="col-md-12">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><a href="<?php echo e(route('solicitante')); ?>">Perfil</a></li>
					<li class="breadcrumb-item active" aria-current="page"> Agregar Solicitud</li>
					<li class="breadcrumb-item active"><a href="<?php echo e(route('VerTabla')); ?>"> Ver Estados de Solicitud </a></li>
				</ol>
			</div>
		</div>
		<h4 class="tituloSolicitud">SOLICITUD DE REQUERIMIENTO DEL BIEN O SERVICIO</h4>
		<div class="col col-lg-3">
			<div class="card-body">
				<div class="container mt-4">
					<div class="alert alert-success" style="display:none"></div>
					 <form id="formSolicitud" name="formSolicitud" method="post">
						<?php echo e(csrf_field()); ?>

						<div class="formulario">
							<div class="form-group">
								<div class="labelNumeroSolicitud">
									<label for="numeroSolicitud" align="right">Numero de Solicitud: </label>
								</div>
								<div class="numeroSolicitud">
									<input type="text" class="form-control" id="numeroSolicitud" name="numeroSolicitud" required>
								</div>
								<div class="labelFecha">
									<label for="fecha" align="right">Fecha: </label>
								</div>
								<div class="fecha">
									<input type="date" class="form-control" id="fecha" placeHolder="dd/mm/yyyy" name="fecha" required>
								</div>
								<div class="labelUnidad">
									<label for="unidad">Unidad Solicitante: </label>
								</div>
								<div class="unidad">
									<input type="text" class="form-control" id="unidad" placeHolder="Ingrese unidad solicitante....." name="unidad" required>
								</div>
								<div class="labelBien">
									<label for="unidad">Nombre Bien/Servicio: </label>
								</div>
								<div class="nombreBien">
									<input type="text" class="form-control" id="nombre" placeHolder="Ingrese nombre del bien o servicio....." name="nombre" required>
								</div>
								<div class="labelDescripcionBienServicio">
									<label>Descripcion Bien/Servicio: </label>
								</div>
								<div class="tablaAgregar">
									<table class="table table-striped">
										<thead>
											<tr>
											  <th scope="col">Detalle del Bien/Servicio</th>
											  <th scope="col">Unidad de Medida</th>
											  <th scope="col">Cantidad Requerida</th>
											</tr>
													<td scope="row">
														<div class="columna1">
															<input id="detalle" name="detalle" type="textField" class="form-control input-md" required>
														</div>
													</td>
													<td>
														<div class="columna2">
															<input id="unidadMedida" name="unidadMedida" type="text" class="form-control input-md" required>
														</div>
													</td>
													<td>
														<div class="columna3">
															<input id="cantidad" name="cantidad" type="text" class="form-control input-md" required>
														</div>
													</td>
										</thead>
									</table>
								</div>
								<div class="labelJustificacion">
									<label for="justificacion">Justificacion Bien/Servicio: </label>
								</div>
								<div class="justificacion">
									<input type="text" class="form-control" id="justificacion" name="justificacion" required>
								</div>
								<div class="labelObservaciones">
									<label for="observaciones">Observaciones: </label>
								</div>
								<div class="observaciones">
									<input type="text" class="form-control" id="observaciones" name="observaciones">
								</div>
								<div class="labelFechaAprox">
									<label for="fechaAprox">Fecha aprox. para cuando se requiere: </label>
								</div>
								<div class="fechaAprox">
									<input type="date" class="form-control" id="fechaAprox" placeholder="dd/mm/yyyy" name="fechaAprox" required>
								</div>
							</div>
						</div>
						<button class="btn btn-primary" id="botonEnviar" onclick="agregarSolicitud()">Enviar Solicitud</button>
					</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<script type="text/javascript">
		window.onload = function(){
			$.ajaxSetup({
				headers : {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				}
			});
		}
		function agregarSolicitud()
		{
			$.ajax({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
				},
				type: "POST",
				data: $('#formSolicitud').serialize(),
				url: "<?php echo e(url('/Solicitud')); ?>",
				success: function(response){
					if(response =! 1)
					{
						console.log(response);
					}
					else
					{
						window.location.href = "<?php echo e(url('/PerfilSolicitante')); ?>";
					}
				}
			});
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>