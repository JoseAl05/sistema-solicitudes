@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Registro</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    Registrado con Éxito.!
					Espere que se le asigne un rol dentro del sistema.
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
